function checkAction(checkbox){
    if(checkbox.checked){
        document.getElementById('signup').disabled = false;
    }
    else{
        document.getElementById('signup').disabled = true;
    }
}



function validate(){
    var name = document.getElementById("name").value;
    var age = document.getElementById("age").value;
    var email = document.getElementById("email").value
    var password = document.getElementById("password").value;
    var Confirmpassword = document.getElementById("Confirmpassword").value;
    document.getElementById('teleport').disabled = true;

    if( !name || !age || !email || !password || !Confirmpassword){
        alert("Some Fields are Empty");
        return false;
    }
    
    var x = email.split("@")
    if(x.length != 2){
        alert("Email Invalid");
        return false;
    }
    
    if(age < 0){
    alert("Age Must be Positive number")
    return false;
    }
    
    if(password != Confirmpassword){
        alert("Password not match");
        return false;
    }
    
    alert("The Form Submited");
    
    document.getElementById('teleport').disabled = false;

    return true;

    

}


     
        
    




